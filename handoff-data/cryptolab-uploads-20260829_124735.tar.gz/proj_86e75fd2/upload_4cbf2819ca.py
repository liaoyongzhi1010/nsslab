def mod_inverse(a, modulus):
    return pow(a, -1, modulus)
